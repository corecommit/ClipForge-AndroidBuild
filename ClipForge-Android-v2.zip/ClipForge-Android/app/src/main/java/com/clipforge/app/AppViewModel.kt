package com.clipforge.app

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import com.clipforge.app.data.AppDb
import com.clipforge.app.data.ClipEntity
import com.clipforge.app.data.Paths
import com.clipforge.app.data.ProjectEntity
import com.clipforge.app.engine.AspectMode
import com.clipforge.app.engine.AudioAnalyzer
import com.clipforge.app.engine.ClipMedia
import com.clipforge.app.engine.Gallery
import com.clipforge.app.engine.HighlightDetector
import com.clipforge.app.engine.Meta
import com.clipforge.app.engine.Quality
import com.clipforge.app.engine.SceneAnalyzer
import com.clipforge.app.engine.Thumbs
import com.clipforge.app.engine.YouTubeFetcher
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class Pending(
    val kind: String,              // LOCAL | YOUTUBE
    val title: String,
    val durationMs: Long,
    val thumb: Bitmap?,
    val url: String?,
    val localPath: String?,        // null until a YouTube video has been downloaded
    val stagingDir: File?
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data class Loading(val message: String, val progress: Float?) : ImportUi
    data class Ready(val pending: Pending) : ImportUi
    data class Error(val message: String) : ImportUi
}

data class AnalysisUi(
    val projectId: String,
    val stage: String,
    val progress: Float,
    val error: String? = null,
    val done: Boolean = false
)

data class ExportUi(
    val running: Boolean = false,
    val index: Int = 0,
    val total: Int = 0,
    val progress: Float = 0f,
    val saved: List<Pair<String, Uri>> = emptyList(),
    val error: String? = null,
    val finished: Boolean = false
)

@UnstableApi
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx get() = getApplication<Application>()
    private val dao = AppDb.get(app).dao()

    val projects: StateFlow<List<ProjectEntity>> =
        dao.projects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val clipCounts: StateFlow<Map<String, Int>> =
        dao.clipCounts().map { list -> list.associate { it.projectId to it.n } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun project(id: String) = dao.project(id)
    fun clips(id: String) = dao.clips(id)

    val importUi = MutableStateFlow<ImportUi>(ImportUi.Idle)
    val analysisUi = MutableStateFlow<AnalysisUi?>(null)
    val exportUi = MutableStateFlow(ExportUi())
    /** One-off message shown on the Source screen (e.g. a failed download). */
    val notice = MutableStateFlow<String?>(null)

    private var importJob: Job? = null
    private var analysisJob: Job? = null
    private var exportJob: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            dao.failInterrupted()
            Paths.staging(ctx).deleteRecursively()   // leftovers from an interrupted import
        }
    }

    // ------------------------------------------------------------------ import

    fun importLocal(uri: Uri) {
        if (importUi.value is ImportUi.Loading) return
        importJob = viewModelScope.launch {
            importUi.value = ImportUi.Loading("Reading video…", 0f)
            val dir = File(Paths.staging(ctx), UUID.randomUUID().toString()).apply { mkdirs() }
            try {
                val (name, size) = withContext(Dispatchers.IO) { nameAndSize(uri) }
                val ext = name.substringAfterLast('.', "mp4").lowercase()
                    .takeIf { it in setOf("mp4", "mov", "mkv", "webm", "m4v", "3gp") } ?: "mp4"
                val dest = File(dir, "source.$ext")
                withContext(Dispatchers.IO) {
                    val input = ctx.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Can't open the selected file.")
                    input.use { i ->
                        dest.outputStream().use { o ->
                            val buf = ByteArray(256 * 1024)
                            var copied = 0L
                            while (true) {
                                val n = i.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                copied += n
                                if (size > 0) importUi.value = ImportUi.Loading("Reading video…", copied.toFloat() / size)
                            }
                        }
                    }
                }
                val meta = withContext(Dispatchers.IO) { Meta.read(dest.path) }
                    ?: throw IllegalStateException("This file can't be read as a video. Try MP4, MOV, MKV or WEBM.")
                val thumb = withContext(Dispatchers.IO) { Thumbs.bitmap(dest.path, meta.durationMs / 10) }
                importUi.value = ImportUi.Ready(
                    Pending("LOCAL", name.substringBeforeLast('.'), meta.durationMs, thumb, null, dest.path, dir)
                )
            } catch (e: CancellationException) {
                dir.deleteRecursively()
                throw e
            } catch (e: Throwable) {
                dir.deleteRecursively()
                importUi.value = ImportUi.Error(e.message ?: "Could not import this video.")
            }
        }
    }

    private fun nameAndSize(uri: Uri): Pair<String, Long> {
        var name = "video"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        return name to size
    }

    fun fetchYoutube(rawUrl: String) {
        val url = rawUrl.trim()
        if (importUi.value is ImportUi.Loading) return
        if (!YouTubeFetcher.isValid(url)) {
            importUi.value = ImportUi.Error("That doesn't look like a YouTube link. It should start with https://youtube.com/ or https://youtu.be/")
            return
        }
        importJob = viewModelScope.launch {
            importUi.value = ImportUi.Loading("Getting video info… (first time can take a minute)", null)
            try {
                val info = YouTubeFetcher.info(ctx, url)
                val thumb = YouTubeFetcher.thumbnail(info.thumbUrl)
                importUi.value = ImportUi.Ready(Pending("YOUTUBE", info.title, info.durationMs, thumb, url, null, null))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                importUi.value = ImportUi.Error(
                    "This video can't be accessed (it may be private, restricted, removed, or you're offline). ${e.message?.lineSequence()?.firstOrNull().orEmpty()}".trim()
                )
            }
        }
    }

    fun downloadYoutube() {
        val p = (importUi.value as? ImportUi.Ready)?.pending ?: return
        val url = p.url ?: return
        importJob = viewModelScope.launch {
            val dir = File(Paths.staging(ctx), UUID.randomUUID().toString()).apply { mkdirs() }
            importUi.value = ImportUi.Loading("Downloading video…", 0f)
            try {
                val file = YouTubeFetcher.download(ctx, url, dir) {
                    importUi.value = ImportUi.Loading("Downloading video…", it)
                }
                val meta = withContext(Dispatchers.IO) { Meta.read(file.path) }
                    ?: throw IllegalStateException("The downloaded file can't be played.")
                importUi.value = ImportUi.Ready(
                    Pending("YOUTUBE", p.title, meta.durationMs, p.thumb, url, file.path, dir)
                )
            } catch (e: CancellationException) {
                dir.deleteRecursively()
                throw e
            } catch (e: Throwable) {
                dir.deleteRecursively()
                importUi.value = ImportUi.Ready(p)
                notice.value = "YouTube download failed: ${e.message?.lineSequence()?.firstOrNull() ?: "check the link and your connection."}"
            }
        }
    }

    fun clearImport() {
        importJob?.cancel()
        val s = importUi.value
        if (s is ImportUi.Ready) s.pending.stagingDir?.deleteRecursively()
        importUi.value = ImportUi.Idle
        notice.value = null
    }

    // ---------------------------------------------------------------- analysis

    /** Starts analysis of the prepared video. Returns the new project id, or null if nothing is ready. */
    fun startAnalysis(): String? {
        val p = (importUi.value as? ImportUi.Ready)?.pending ?: return null
        if (p.localPath == null || p.stagingDir == null) return null
        val id = UUID.randomUUID().toString()
        analysisUi.value = AnalysisUi(id, "Preparing…", 0f)
        importUi.value = ImportUi.Idle
        analysisJob = viewModelScope.launch { runAnalysis(id, p) }
        return id
    }

    private fun setStage(id: String, stage: String, progress: Float) {
        analysisUi.value = AnalysisUi(id, stage, progress.coerceIn(0f, 1f))
    }

    private suspend fun runAnalysis(id: String, p: Pending) {
        val projDir = File(Paths.projects(ctx), id)
        try {
            val staging = p.stagingDir!!
            withContext(Dispatchers.IO) {
                projDir.parentFile?.mkdirs()
                if (!staging.renameTo(projDir)) {
                    staging.copyRecursively(projDir, overwrite = true)
                    staging.deleteRecursively()
                }
            }
            val src = File(projDir, File(p.localPath!!).name)
            val duration = p.durationMs
            val thumbFile = File(projDir, "thumb.jpg")
            withContext(Dispatchers.IO) { Thumbs.save(src.path, duration / 10, thumbFile) }

            dao.upsert(
                ProjectEntity(
                    id = id, title = p.title, sourceTitle = p.title, createdAt = System.currentTimeMillis(),
                    durationMs = duration, thumbPath = thumbFile.takeIf { it.exists() }?.path,
                    status = "ANALYZING", statusMessage = null, sourcePath = src.path, sourceKind = p.kind
                )
            )

            setStage(id, "Listening to the audio…", 0f)
            val audio = AudioAnalyzer.analyze(src.path, duration) { setStage(id, "Listening to the audio…", it * 0.35f) }

            setStage(id, "Scanning the picture for cuts and motion…", 0.35f)
            val visual = SceneAnalyzer.analyze(src.path, duration) {
                setStage(id, "Scanning the picture for cuts and motion…", 0.35f + it * 0.25f)
            }

            setStage(id, "Ranking the best moments…", 0.6f)
            val found = withContext(Dispatchers.Default) { HighlightDetector.detect(audio, visual, duration) }

            var made = 0
            found.forEachIndexed { i, d ->
                val base = 0.65f + 0.35f * i / found.size
                setStage(id, "Cutting clip ${i + 1} of ${found.size}…", base)
                val clipId = UUID.randomUUID().toString()
                val out = File(projDir, "clips/$clipId.mp4")
                try {
                    ClipMedia.cut(ctx, src.path, d.startMs, d.endMs, out)
                    val thumb = File(projDir, "clips/$clipId.jpg")
                    withContext(Dispatchers.IO) { Thumbs.save(out.path, 1000, thumb) }
                    dao.insertClip(
                        ClipEntity(
                            id = clipId, projectId = id, title = d.title, category = d.category, score = d.score,
                            startMs = d.startMs, endMs = d.endMs, filePath = out.path,
                            thumbPath = thumb.takeIf { it.exists() }?.path
                        )
                    )
                    made++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    out.delete()   // skip this clip, keep going
                }
            }
            if (made == 0) throw IllegalStateException("Highlights were found but none of the clips could be rendered on this device.")

            dao.setStatus(id, "READY", null)
            analysisUi.value = AnalysisUi(id, "Done", 1f, done = true)
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                projDir.deleteRecursively()
                p.stagingDir?.deleteRecursively()
                dao.deleteProject(id)
            }
            analysisUi.value = null
            throw e
        } catch (e: Throwable) {
            val msg = e.message ?: "Analysis failed."
            withContext(NonCancellable) { dao.setStatus(id, "FAILED", msg) }
            analysisUi.value = AnalysisUi(id, "Failed", 0f, error = msg)
        }
    }

    fun cancelAnalysis() {
        analysisJob?.cancel()
        analysisUi.value = null
    }

    fun clearAnalysis() {
        analysisUi.value = null
    }

    // ------------------------------------------------------------------ export

    fun export(clips: List<ClipEntity>, aspect: AspectMode, quality: Quality) {
        if (exportUi.value.running || clips.isEmpty()) return
        exportJob = viewModelScope.launch {
            exportUi.value = ExportUi(running = true, total = clips.size)
            val saved = ArrayList<Pair<String, Uri>>()
            var tmp: File? = null
            try {
                clips.forEachIndexed { i, c ->
                    val file = File(c.filePath)
                    if (!file.exists()) throw IllegalStateException("The file for \"${c.title}\" is missing from storage.")
                    val toSave: File
                    if (aspect.ratio == null) {
                        toSave = file    // original aspect: copy the clip as-is, no quality loss
                    } else {
                        val out = File(ctx.cacheDir, "export_${c.id}.mp4")
                        tmp = out
                        ClipMedia.render(ctx, file, out, aspect, quality) { p ->
                            exportUi.value = exportUi.value.copy(index = i, progress = p)
                        }
                        toSave = out
                    }
                    exportUi.value = exportUi.value.copy(index = i, progress = 1f)
                    val uri = withContext(Dispatchers.IO) { Gallery.save(ctx, toSave, c.title) }
                    tmp?.delete()
                    tmp = null
                    saved.add(c.title to uri)
                }
                exportUi.value = ExportUi(total = clips.size, saved = saved, finished = true)
            } catch (e: CancellationException) {
                tmp?.delete()
                exportUi.value = ExportUi()
                throw e
            } catch (e: Throwable) {
                tmp?.delete()
                exportUi.value = ExportUi(total = clips.size, saved = saved, error = e.message ?: "Export failed.")
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
    }

    fun resetExport() {
        exportUi.value = ExportUi()
    }

    // ------------------------------------------------------------------ delete

    fun deleteClip(c: ClipEntity) {
        viewModelScope.launch {
            dao.deleteClip(c.id)
            withContext(Dispatchers.IO) {
                File(c.filePath).delete()
                c.thumbPath?.let { File(it).delete() }
            }
        }
    }

    fun deleteProject(p: ProjectEntity) {
        viewModelScope.launch {
            dao.deleteProject(p.id)   // clips rows are removed by cascade
            withContext(Dispatchers.IO) { File(Paths.projects(ctx), p.id).deleteRecursively() }
        }
    }
}
