package com.clipforge.app.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Bg = Color(0xFF0D0F0E)
val Bg2 = Color(0xFF141716)
val CardBg = Color(0xFF1B1F1D)
val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFA5AAA7)
val Accent = Color(0xFF9C8CFF)      // soft violet
val Accent2 = Color(0xFF5CC8D7)     // calm teal
val Danger = Color(0xFFFF7A7A)

val AccentBrush = Brush.horizontalGradient(listOf(Accent, Accent2))

@Composable
fun ClipForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF14102B),
            secondary = Accent2,
            background = Bg,
            onBackground = TextPrimary,
            surface = Bg2,
            onSurface = TextPrimary,
            surfaceVariant = CardBg,
            onSurfaceVariant = TextSecondary,
            error = Danger,
            outline = Color(0xFF3A403D)
        ),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}
