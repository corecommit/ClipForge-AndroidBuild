package com.clipforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.clipforge.app.ui.AnalysisScreen
import com.clipforge.app.ui.ClipForgeTheme
import com.clipforge.app.ui.HomeScreen
import com.clipforge.app.ui.ProjectsScreen
import com.clipforge.app.ui.ResultsScreen
import com.clipforge.app.ui.SourceScreen

@UnstableApi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { ClipForgeTheme { App() } }
    }
}

@UnstableApi
@Composable
private fun App() {
    val nav = rememberNavController()
    val vm: AppViewModel = viewModel()
    val idArg = listOf(navArgument("id") { type = NavType.StringType })

    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, nav) }
        composable("source") { SourceScreen(vm, nav) }
        composable("analysis/{id}", idArg) { AnalysisScreen(vm, nav, it.arguments?.getString("id").orEmpty()) }
        composable("results/{id}", idArg) { ResultsScreen(vm, nav, it.arguments?.getString("id").orEmpty()) }
        composable("projects") { ProjectsScreen(vm, nav) }
    }
}
