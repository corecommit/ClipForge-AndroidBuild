package com.clipforge.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import java.io.File

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sourceTitle: String,
    val createdAt: Long,
    val durationMs: Long,
    val thumbPath: String?,
    val status: String,            // ANALYZING | READY | FAILED
    val statusMessage: String?,
    val sourcePath: String,
    val sourceKind: String         // LOCAL | YOUTUBE
)

@Entity(
    tableName = "clips",
    foreignKeys = [ForeignKey(
        entity = ProjectEntity::class,
        parentColumns = ["id"],
        childColumns = ["projectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("projectId")]
)
data class ClipEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val title: String,
    val category: String,
    val score: Int,
    val startMs: Long,
    val endMs: Long,
    val filePath: String,
    val thumbPath: String?
)

data class ClipCount(val projectId: String, val n: Int)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun projects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun project(id: String): Flow<ProjectEntity?>

    @Query("SELECT * FROM clips WHERE projectId = :id ORDER BY score DESC")
    fun clips(id: String): Flow<List<ClipEntity>>

    @Query("SELECT projectId, COUNT(*) AS n FROM clips GROUP BY projectId")
    fun clipCounts(): Flow<List<ClipCount>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(c: ClipEntity)

    @Query("UPDATE projects SET status = :status, statusMessage = :message WHERE id = :id")
    suspend fun setStatus(id: String, status: String, message: String?)

    @Query("UPDATE projects SET status = 'FAILED', statusMessage = 'Interrupted: the app was closed while analysing.' WHERE status = 'ANALYZING'")
    suspend fun failInterrupted()

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: String)

    @Query("DELETE FROM clips WHERE id = :id")
    suspend fun deleteClip(id: String)
}

@Database(entities = [ProjectEntity::class, ClipEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ProjectDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "clipforge.db")
                .build().also { instance = it }
        }
    }
}

object Paths {
    fun projects(ctx: Context) = File(ctx.filesDir, "projects")
    fun staging(ctx: Context) = File(ctx.filesDir, "staging")
}
