package com.clipforge.app.engine

import kotlin.math.ceil
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class DetectedClip(
    val startMs: Long,
    val endMs: Long,
    val score: Int,
    val category: String,
    val title: String
)

/** User choices made before analysis. count = 0 means "decide automatically". */
data class ClipSettings(val minSec: Int = 15, val maxSec: Int = 45, val count: Int = 0)

/**
 * Turns the measured audio loudness and picture-change signals into ranked highlight clips.
 *
 * Per second of video it scores:
 *   - loudness (how loud this second is compared with the rest of the video)
 *   - build-up (a sudden jump in loudness compared with the previous seconds: laughs, shouts, impacts)
 *   - visual change (cuts and motion)
 * then smooths the score, picks the strongest non-overlapping peaks, and moves each clip's start and end
 * to the nearest quiet moment (a pause) so clips don't cut mid-sound.
 *
 * This is signal analysis, not understanding of what is said or shown. Categories describe the signal.
 */
object HighlightDetector {

    fun detect(
        audio: FloatArray,
        visual: List<VisualSample>,
        durationMs: Long,
        settings: ClipSettings = ClipSettings()
    ): List<DetectedClip> {
        val n = ceil(durationMs / 1000.0).toInt()
        if (n < 12) throw IllegalStateException("This video is too short to find highlights in (about 12 seconds minimum).")

        val hasAudio = audio.isNotEmpty() && audio.any { it > 0.0005f }
        val hasVisual = visual.any { it.change > 0f }
        if (!hasAudio && !hasVisual) {
            throw IllegalStateException("No usable audio or picture signal was found in this video.")
        }

        // --- per-second loudness in dB ---
        val db = FloatArray(n) { -100f }
        if (hasAudio) {
            for (w in audio.indices) {
                val s = (w.toLong() * AudioAnalyzer.HOP_MS / 1000).toInt()
                if (s < n) {
                    val v = 20f * log10(audio[w] + 1e-5f)
                    if (v > db[s]) db[s] = v
                }
            }
        }
        val energy = if (hasAudio) normalizeRange(db) else FloatArray(n)

        // --- build-up: loudness above the average of the previous 6 seconds ---
        val rise = FloatArray(n)
        if (hasAudio) {
            for (s in 0 until n) {
                if (s == 0) continue
                var sum = 0f
                val from = max(0, s - 6)
                for (k in from until s) sum += db[k]
                rise[s] = max(0f, db[s] - sum / (s - from))
            }
        }
        val riseN = normalizeTop(rise)

        // --- visual change, spread across the seconds each sample represents ---
        val vis = FloatArray(n)
        val sorted = visual.sortedBy { it.timeMs }
        for (i in sorted.indices) {
            val from = (sorted[i].timeMs / 1000).toInt()
            val to = if (i + 1 < sorted.size) (sorted[i + 1].timeMs / 1000).toInt() else min(n, from + 1)
            for (s in from until min(to, n)) if (s >= 0) vis[s] = max(vis[s], sorted[i].change)
        }
        val visN = normalizeTop(vis)

        val (wE, wR, wV) = when {
            hasAudio && hasVisual -> Triple(0.45f, 0.30f, 0.25f)
            hasAudio -> Triple(0.60f, 0.40f, 0f)
            else -> Triple(0f, 0f, 1f)
        }
        val raw = FloatArray(n) { wE * energy[it] + wR * riseN[it] + wV * visN[it] }
        val sm = FloatArray(n) { s ->
            var sum = 0f
            var cnt = 0
            for (k in max(0, s - 2)..min(n - 1, s + 2)) { sum += raw[k]; cnt++ }
            sum / cnt
        }

        // --- choose peaks ---
        val minLen = settings.minSec.coerceIn(5, n)
        val maxLen = settings.maxSec.coerceIn(minLen, n)
        val target = when {
            settings.count > 0 -> settings.count
            n < 45 -> 1
            else -> (n / 120).coerceIn(2, 10)
        }
        val floor = if (settings.count > 0) 0.08f else 0.2f
        val order = (0 until n).sortedByDescending { sm[it] }
        val chosen = ArrayList<IntArray>()
        val results = ArrayList<DetectedClip>()

        for (p in order) {
            if (results.size >= target) break
            if (sm[p] < floor) break
            if (chosen.any { p >= it[0] - 5 && p <= it[1] + 5 }) continue

            val startLo = max(0, p - (maxLen * 0.45f).toInt())
            val startHi = max(startLo, p - 3)
            var s = if (hasAudio) quietest(db, startLo, startHi, preferLate = true) else max(0, p - maxLen / 3)
            var e: Int
            if (hasAudio) {
                val endHi = min(n, s + maxLen)
                val endLo = min(endHi, max(p + 4, s + minLen))
                e = quietest(db, endLo, endHi, preferLate = false)
            } else {
                e = min(n, s + (minLen + maxLen) / 2)
            }
            if (e - s < minLen) e = min(n, s + minLen)
            if (e - s < minLen) s = max(0, e - minLen)
            if (e - s > maxLen) e = s + maxLen
            if (chosen.any { s < it[1] + 2 && e > it[0] - 2 }) continue

            chosen.add(intArrayOf(s, e))

            val cE = wE * energy[p]
            val cR = wR * riseN[p]
            val cV = wV * visN[p]
            val category = when {
                energy[p] > 0.6f && visN[p] > 0.6f -> "High-energy scene"
                cR >= cE && cR >= cV && cR > 0f -> "Sudden build-up"
                cE >= cV && cE > 0f -> "Loud moment"
                else -> "Visual change"
            }
            results.add(
                DetectedClip(
                    startMs = s * 1000L,
                    endMs = min(durationMs, e * 1000L),
                    score = (sm[p] * 100).roundToInt().coerceIn(1, 99),
                    category = category,
                    title = "$category at ${stamp(p)}"
                )
            )
        }

        if (results.isEmpty()) {
            throw IllegalStateException("No standout moments were found. The video may be too flat (constant volume, no visual changes).")
        }
        return results.sortedByDescending { it.score }
    }

    private fun stamp(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    /** Index of the lowest-loudness second in [lo, hi]; on ties prefers the late or early side. */
    private fun quietest(db: FloatArray, lo: Int, hi: Int, preferLate: Boolean): Int {
        val a = lo.coerceIn(0, db.size - 1)
        val b = hi.coerceIn(a, db.size - 1)
        var best = a
        for (i in a..b) {
            val better = if (preferLate) db[i] <= db[best] else db[i] < db[best]
            if (better) best = i
        }
        return best
    }

    private fun percentile(values: FloatArray, p: Float): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sortedArray()
        return sorted[((sorted.size - 1) * p).toInt()]
    }

    /** Maps the 10th..95th percentile range to 0..1. */
    private fun normalizeRange(v: FloatArray): FloatArray {
        val lo = percentile(v, 0.10f)
        val hi = percentile(v, 0.95f)
        if (hi - lo < 1e-3f) return FloatArray(v.size)
        return FloatArray(v.size) { ((v[it] - lo) / (hi - lo)).coerceIn(0f, 1f) }
    }

    /** Scales so the 95th percentile becomes 1.0. */
    private fun normalizeTop(v: FloatArray): FloatArray {
        val hi = percentile(v, 0.95f)
        if (hi < 1e-4f) return FloatArray(v.size)
        return FloatArray(v.size) { (v[it] / hi).coerceIn(0f, 1f) }
    }
}
