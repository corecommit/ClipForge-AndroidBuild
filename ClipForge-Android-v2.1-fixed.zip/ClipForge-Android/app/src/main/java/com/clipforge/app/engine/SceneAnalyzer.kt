package com.clipforge.app.engine

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs

/** change: 0..1 amount the picture changed compared with the previous sample (cuts, motion). */
class VisualSample(val timeMs: Long, val change: Float)

/**
 * Samples real frames from the video and measures how much the picture changes between samples.
 * Large changes indicate scene cuts or lots of on-screen motion.
 */
object SceneAnalyzer {
    private const val W = 48
    private const val H = 27
    private const val BINS = 16

    suspend fun analyze(path: String, durationMs: Long, onProgress: (Float) -> Unit): List<VisualSample> =
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(path)
                val stepMs = maxOf(1000L, durationMs / 1200L)
                val out = ArrayList<VisualSample>()
                var prevLuma: IntArray? = null
                var prevHist: FloatArray? = null
                var t = 0L
                while (t < durationMs) {
                    ensureActive()
                    val frame = retriever.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (frame != null) {
                        val small = Bitmap.createScaledBitmap(frame, W, H, true)
                        if (small !== frame) frame.recycle()
                        val px = IntArray(W * H)
                        small.getPixels(px, 0, W, 0, 0, W, H)
                        small.recycle()
                        val luma = IntArray(px.size)
                        val hist = FloatArray(BINS)
                        for (i in px.indices) {
                            val p = px[i]
                            val r = (p shr 16) and 0xFF
                            val g = (p shr 8) and 0xFF
                            val b = p and 0xFF
                            val y = (r * 299 + g * 587 + b * 114) / 1000
                            luma[i] = y
                            hist[(y * BINS) / 256]++
                        }
                        for (i in hist.indices) hist[i] /= px.size
                        val pl = prevLuma
                        val ph = prevHist
                        if (pl != null && ph != null) {
                            var hd = 0f
                            for (i in hist.indices) hd += abs(hist[i] - ph[i])
                            hd /= 2f
                            var md = 0f
                            for (i in luma.indices) md += abs(luma[i] - pl[i])
                            md /= (luma.size * 255f)
                            out.add(VisualSample(t, (0.6f * hd + 0.4f * md * 3f).coerceIn(0f, 1f)))
                        }
                        prevLuma = luma
                        prevHist = hist
                    }
                    t += stepMs
                    onProgress((t.toFloat() / durationMs).coerceIn(0f, 1f))
                }
                onProgress(1f)
                out
            } finally {
                retriever.release()
            }
        }
}
