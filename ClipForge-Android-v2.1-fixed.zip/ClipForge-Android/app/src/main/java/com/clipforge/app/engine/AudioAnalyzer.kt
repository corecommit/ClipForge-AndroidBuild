package com.clipforge.app.engine

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Decodes the real audio track of the video and measures loudness (RMS) in 0.5 s windows.
 * Returns an empty array when the video has no audio track.
 */
object AudioAnalyzer {
    const val HOP_MS = 500

    suspend fun analyze(path: String, durationMs: Long, onProgress: (Float) -> Unit): FloatArray =
        withContext(Dispatchers.IO) {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(path)
                var track = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                        track = i
                        format = f
                        break
                    }
                }
                if (track < 0 || format == null) return@withContext FloatArray(0)

                extractor.selectTrack(track)
                val mime = format.getString(MediaFormat.KEY_MIME)!!
                val c = MediaCodec.createDecoderByType(mime)
                codec = c
                c.configure(format, null, null, 0)
                c.start()

                var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                var windowFrames = (rate.toLong() * HOP_MS / 1000).toInt().coerceAtLeast(1)

                val windows = ArrayList<Float>()
                var sumSq = 0.0
                var framesInWindow = 0
                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false

                while (!outputDone) {
                    ensureActive()
                    if (!inputDone) {
                        val inIdx = c.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val buf = c.getInputBuffer(inIdx)!!
                            val n = extractor.readSampleData(buf, 0)
                            if (n < 0) {
                                c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIdx = c.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIdx >= 0 -> {
                            val out = c.getOutputBuffer(outIdx)!!
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val shorts = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            while (shorts.remaining() >= channels) {
                                var frame = 0.0
                                for (ch in 0 until channels) {
                                    val v = shorts.get() / 32768.0
                                    frame += v * v
                                }
                                sumSq += frame / channels
                                framesInWindow++
                                if (framesInWindow >= windowFrames) {
                                    windows.add(sqrt(sumSq / framesInWindow).toFloat())
                                    sumSq = 0.0
                                    framesInWindow = 0
                                }
                            }
                            if (durationMs > 0) {
                                onProgress((info.presentationTimeUs / 1000f / durationMs).coerceIn(0f, 1f))
                            }
                            c.releaseOutputBuffer(outIdx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        }
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val nf = c.outputFormat
                            rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                            windowFrames = (rate.toLong() * HOP_MS / 1000).toInt().coerceAtLeast(1)
                        }
                    }
                }
                if (framesInWindow > 0) windows.add(sqrt(sumSq / framesInWindow).toFloat())
                onProgress(1f)
                windows.toFloatArray()
            } finally {
                try { codec?.stop() } catch (_: Exception) {}
                try { codec?.release() } catch (_: Exception) {}
                extractor.release()
            }
        }
}
