# ClipForge for Android (v2.4)

Automatic highlight clipper. Give it a video; it finds the most eventful moments and cuts them into
separate, playable MP4 clips. No manual trimming.

Kotlin, Jetpack Compose (Material 3), Media3 (ExoPlayer + Transformer), Room, yt-dlp (youtubedl-android).
Requires Android 10 (API 29) or newer.

## Get the APK (no Android Studio needed)
1. Push this folder to a GitHub repo on branch `main`.
2. Repo, **Actions** tab, latest **Build Android APK** run, download **app-debug-apk**, unzip, install.
   (Allow "install unknown apps". The APK is large because it bundles Python + yt-dlp.)
3. If the build fails, open the failed run and copy the error. Version pins in `build.gradle.kts` /
   `app/build.gradle.kts` are the most likely cause.

## How highlight detection works (what is real, what is not)
Everything runs on the phone. No cloud service, no API key, nothing is faked.

1. **Audio**: the real audio track is decoded and measured every 0.5 s: loudness, sharp peaks (impacts,
   gunshots, explosions) and brightness (screaming / hype sounds brighter than game music or a calm voice).
2. **Picture**: at each sample point two exact frames 0.25 s apart are compared (fast action, effects) and the
   moment is compared with the previous sample (cuts, flashes).
3. **Scoring**: per second = loudness + **build-up vs the last 30 s** (adapts to constant music/chatter) +
   excitement (loud and bright) + hits + visual change, smoothed, with a bonus for moments that keep going.
4. **Selection**: weights adapt to the video (flat audio or a static picture counts for less). Clips are built
   around the strongest moments: they start where the action began building and end after it calms down, inside
   your length limits, and clips are spread apart so one fight doesn't give several near-identical clips.
   Strongest peaks win (in Auto mode only moments clearly stronger than the
   video's usual level are kept); each clip's start/end is moved to the nearest quiet moment so it doesn't cut
   mid-sound; clip length is your choice (default 15-45 s).
5. **Cutting**: each clip is a real file cut from your video with Media3 Transformer.

**Not implemented (yet):** speech recognition / understanding what is said, emotion or face detection,
"funny / emotional / viral" classification. Categories shown ("Loud moment", "Sudden build-up",
"Shout / hype", "Big hit", "Visual change", "High-energy scene") describe the *signal*, not the meaning. The score is a relative
signal strength, not a prediction of virality. Adding transcripts + an LLM judge needs a speech-to-text
engine (e.g. on-device Whisper/Vosk) and optionally a cloud API with your own key; that would be the next step.

## Other behaviour to know
- **Clip preview** is full screen: swipe up/down (or use the arrow buttons) to move between clips, the clip on screen
  plays on a loop, and you can switch Original / 9:16 / 1:1 to see the crop before exporting.
- **Vertical / square export** is a centre crop (Media3 `Presentation`). It does not track faces.
  You can preview the crop before exporting. "Original" exports copy the clip untouched.
- **Projects** live in a Room database; media in the app's private storage (kept until you delete them).
  Each project keeps a copy of its source video, so large videos use phone storage.
- **Background analysis**: analysis runs in a foreground service (notification with progress, wake lock), so it
  keeps going when you leave the app or the screen turns off. You get a "highlights are ready" notification when
  it finishes. Android 13+ asks for notification permission the first time; analysis runs even if you say no.
  If Android still kills the app mid-analysis, the project is marked "Didn't finish" and can be retried.
- **Continue tab** (Home): lists projects that are still analysing, analysed but never exported, or interrupted.
  Tap to resume, "Retry" re-analyses from the saved video, "Dismiss" hides a project from the tab (clips stay in
  My Projects). A clip counts as exported once it has been saved to the gallery.
- YouTube: downloads with yt-dlp. Private / restricted / removed videos fail with an error. YouTube changes often;
  if downloads stop working the bundled yt-dlp may need updating (bump the library version).
  Only use videos you own or have permission to save.

## Status
Written without access to an Android SDK or device, so **it has not been compiled or run**. First CI build
may need small fixes. Use the end-to-end checklist from the original prompt once it installs.

## v3.0
- Smarter clip finder: detects emphatic speech, reveals (quiet beat then burst), laughs/applause/crowd reactions, plus action; scores whole clip windows on hook, payoff and arc; cuts snap to pauses.
- iOS-style frosted glass UI over a glowing backdrop; new logo and app icon.
- Export now also keeps running in the background (notification + wake lock), like analysis.

## v4.0
- On-device speech recognition (Vosk, free, offline; ~40 MB English model downloaded once on first analysis).
- Clip finder now uses the words: hook lines, questions, emotional lines; avoids dead air and "um/uh" stretches; cuts on sentence boundaries; clip titles preview the first words.
- YouTube downloads also run in the background.
