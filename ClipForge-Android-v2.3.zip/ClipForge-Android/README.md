# ClipForge for Android (v2.3)

Automatic highlight clipper. Give it a video; it finds the most eventful moments and cuts them into
separate, playable MP4 clips. No manual trimming.

Kotlin, Jetpack Compose (Material 3), Media3 (ExoPlayer + Transformer), Room, yt-dlp (youtubedl-android).
Requires Android 10 (API 29) or newer.

## Get the APK (no Android Studio needed)
1. Push this folder to a GitHub repo on branch `main`.
2. Repo, **Actions** tab, latest **Build Android APK** run, download **app-debug-apk**, unzip, install.
   (Allow "install unknown apps". The APK is large because it bundles Python + yt-dlp.)
3. If the build fails, open the failed run and copy the error. Version pins in `build.gradle.kts` /
   `app/build.gradle.kts` are the most likely cause.

## How highlight detection works (what is real, what is not)
Everything runs on the phone. No cloud service, no API key, nothing is faked.

1. **Audio**: the real audio track is decoded and measured every 0.5 s: loudness, sharp peaks (impacts,
   gunshots, explosions) and brightness (screaming / hype sounds brighter than game music or a calm voice).
2. **Picture**: real frames are sampled and compared to find cuts and heavy motion.
3. **Scoring**: per second = loudness + **build-up vs the last 30 s** (adapts to constant music/chatter) +
   excitement (loud and bright) + hits + visual change, smoothed, with a bonus for moments that keep going.
4. **Selection**: strongest non-overlapping peaks win (in Auto mode only moments clearly stronger than the
   video's usual level are kept); each clip's start/end is moved to the nearest quiet moment so it doesn't cut
   mid-sound; clip length is your choice (default 15-45 s).
5. **Cutting**: each clip is a real file cut from your video with Media3 Transformer.

**Not implemented (yet):** speech recognition / understanding what is said, emotion or face detection,
"funny / emotional / viral" classification. Categories shown ("Loud moment", "Sudden build-up",
"Shout / hype", "Big hit", "Visual change", "High-energy scene") describe the *signal*, not the meaning. The score is a relative
signal strength, not a prediction of virality. Adding transcripts + an LLM judge needs a speech-to-text
engine (e.g. on-device Whisper/Vosk) and optionally a cloud API with your own key; that would be the next step.

## Other behaviour to know
- **Clip preview** is full screen: swipe up/down (or use the arrow buttons) to move between clips, the clip on screen
  plays on a loop, and you can switch Original / 9:16 / 1:1 to see the crop before exporting.
- **Vertical / square export** is a centre crop (Media3 `Presentation`). It does not track faces.
  You can preview the crop before exporting. "Original" exports copy the clip untouched.
- **Projects** live in a Room database; media in the app's private storage (kept until you delete them).
  Each project keeps a copy of its source video, so large videos use phone storage.
- Analysis runs while the app is open. If Android kills the app mid-analysis the project is marked
  "Failed" on next launch (nothing is silently deleted) and you can delete or retry it.
- YouTube: downloads with yt-dlp. Private / restricted / removed videos fail with an error. YouTube changes often;
  if downloads stop working the bundled yt-dlp may need updating (bump the library version).
  Only use videos you own or have permission to save.

## Status
Written without access to an Android SDK or device, so **it has not been compiled or run**. First CI build
may need small fixes. Use the end-to-end checklist from the original prompt once it installs.
