package com.clipforge.app.engine

import kotlin.math.ceil
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class DetectedClip(
    val startMs: Long,
    val endMs: Long,
    val score: Int,
    val category: String,
    val title: String
)

/** User choices made before analysis. count = 0 means "decide automatically". */
data class ClipSettings(val minSec: Int = 15, val maxSec: Int = 45, val count: Int = 0)

/**
 * Turns the measured audio loudness and picture-change signals into ranked highlight clips.
 *
 * Per second of video it scores:
 *   - loudness (how loud this second is compared with the rest of the video)
 *   - build-up (a jump in loudness compared with the last 30 seconds: shouts, fights, big plays)
 *   - excitement (loud AND bright/high-pitched sound: screaming, hype)
 *   - hits (very sharp peaks: impacts, gunshots, explosions)
 *   - visual change (cuts and motion)
 * then smooths the score, picks the strongest non-overlapping peaks, and moves each clip's start and end
 * to the nearest quiet moment (a pause) so clips don't cut mid-sound.
 *
 * This is signal analysis, not understanding of what is said or shown. Categories describe the signal.
 */
object HighlightDetector {

    fun detect(
        audio: AudioSignal,
        visual: List<VisualSample>,
        durationMs: Long,
        settings: ClipSettings = ClipSettings()
    ): List<DetectedClip> {
        val n = ceil(durationMs / 1000.0).toInt()
        if (n < 12) throw IllegalStateException("This video is too short to find highlights in (about 12 seconds minimum).")

        val hasAudio = !audio.isEmpty() && audio.rms.any { it > 0.0005f }
        val hasVisual = visual.any { it.change > 0f }
        if (!hasAudio && !hasVisual) {
            throw IllegalStateException("No usable audio or picture signal was found in this video.")
        }

        // --- per-second audio: loudness (dB), peak (dB), brightness ---
        val db = FloatArray(n) { -100f }
        val peakDb = FloatArray(n) { -100f }
        val brightSum = FloatArray(n)
        val brightCnt = IntArray(n)
        if (hasAudio) {
            for (w in 0 until audio.size) {
                val s = (w.toLong() * AudioAnalyzer.HOP_MS / 1000).toInt()
                if (s >= n) continue
                val v = 20f * log10(audio.rms[w] + 1e-5f)
                if (v > db[s]) db[s] = v
                val pk = 20f * log10(audio.peak[w] + 1e-5f)
                if (pk > peakDb[s]) peakDb[s] = pk
                brightSum[s] += audio.bright[w]
                brightCnt[s]++
            }
        }
        val bright = FloatArray(n) { if (brightCnt[it] > 0) brightSum[it] / brightCnt[it] else 0f }

        // Absolute loudness, 0..1 (quiet 10th percentile .. loud 95th percentile of this video).
        val energy = if (hasAudio) normalizeRange(db) else FloatArray(n)

        // Build-up: how far this second is above what the last 30 seconds sounded like. The median ignores
        // earlier spikes, and it adapts to constant game music / chatter, so only real jumps count.
        val rise = FloatArray(n)
        if (hasAudio) {
            for (s in 1 until n) {
                val from = max(0, s - 30)
                rise[s] = max(0f, db[s] - median(db, from, s))
            }
        }
        val riseN = normalizeTop(rise)

        // Sharp hits: a peak far above the average loudness (impacts, gunshots, explosions), only when loud.
        val crest = FloatArray(n) { max(0f, peakDb[it] - db[it]) }
        val hitN = FloatArray(n)
        if (hasAudio) {
            val cn = normalizeTop(crest)
            for (s in 0 until n) hitN[s] = cn[s] * energy[s]
        }

        // Excitement: bright (high-pitched, sharp) sound that is also loud: shouting, hype, screaming.
        val excN = FloatArray(n)
        if (hasAudio) {
            val bn = normalizeRange(bright)
            for (s in 0 until n) excN[s] = bn[s] * energy[s]
        }

        // --- visual change, spread across the seconds each sample represents ---
        val vis = FloatArray(n)
        val sorted = visual.sortedBy { it.timeMs }
        for (i in sorted.indices) {
            val from = (sorted[i].timeMs / 1000).toInt()
            val to = if (i + 1 < sorted.size) (sorted[i + 1].timeMs / 1000).toInt() else min(n, from + 1)
            for (s in from until min(to, n)) if (s >= 0) vis[s] = max(vis[s], sorted[i].change)
        }
        val visN = normalizeTop(vis)

        // weights: [loudness, build-up, excitement, hits, visual]
        val w = when {
            hasAudio && hasVisual -> floatArrayOf(0.22f, 0.28f, 0.15f, 0.10f, 0.25f)
            hasAudio -> floatArrayOf(0.28f, 0.36f, 0.20f, 0.16f, 0f)
            else -> floatArrayOf(0f, 0f, 0f, 0f, 1f)
        }
        val raw = FloatArray(n) {
            w[0] * energy[it] + w[1] * riseN[it] + w[2] * excN[it] + w[3] * hitN[it] + w[4] * visN[it]
        }

        // Smooth (+-2 s), then favour moments that keep going for a few seconds over one-second blips.
        val sm = FloatArray(n) { s ->
            var sum = 0f
            var cnt = 0
            for (k in max(0, s - 2)..min(n - 1, s + 2)) { sum += raw[k]; cnt++ }
            val local = sum / cnt
            var sus = 0f
            var sc = 0
            for (k in s..min(n - 1, s + 6)) { sus += raw[k]; sc++ }
            0.7f * local + 0.3f * (sus / sc)
        }

        // --- choose peaks ---
        val minLen = settings.minSec.coerceIn(5, n)
        val maxLen = settings.maxSec.coerceIn(minLen, n)
        val target = when {
            settings.count > 0 -> settings.count
            n < 45 -> 1
            else -> (n / 120).coerceIn(2, 10)
        }
        // Automatic mode only keeps moments that are clearly stronger than the video's usual level.
        val floor = if (settings.count > 0) 0.08f else max(0.2f, 0.4f * percentile(sm, 0.99f))
        val order = (0 until n).sortedByDescending { sm[it] }
        val chosen = ArrayList<IntArray>()
        val results = ArrayList<DetectedClip>()

        for (p in order) {
            if (results.size >= target) break
            if (sm[p] < floor) break
            if (chosen.any { p >= it[0] - 5 && p <= it[1] + 5 }) continue

            val startLo = max(0, p - (maxLen * 0.45f).toInt())
            val startHi = max(startLo, p - 3)
            var s = if (hasAudio) quietest(db, startLo, startHi, preferLate = true) else max(0, p - maxLen / 3)
            var e: Int
            if (hasAudio) {
                val endHi = min(n, s + maxLen)
                val endLo = min(endHi, max(p + 4, s + minLen))
                e = quietest(db, endLo, endHi, preferLate = false)
            } else {
                e = min(n, s + (minLen + maxLen) / 2)
            }
            if (e - s < minLen) e = min(n, s + minLen)
            if (e - s < minLen) s = max(0, e - minLen)
            if (e - s > maxLen) e = s + maxLen
            if (chosen.any { s < it[1] + 2 && e > it[0] - 2 }) continue

            chosen.add(intArrayOf(s, e))

            val parts = listOf(
                "Sudden build-up" to w[1] * riseN[p],
                "Shout / hype" to w[2] * excN[p],
                "Big hit" to w[3] * hitN[p],
                "Loud moment" to w[0] * energy[p],
                "Visual change" to w[4] * visN[p]
            )
            val best = parts.maxByOrNull { it.second }
            val category = when {
                energy[p] > 0.6f && visN[p] > 0.6f -> "High-energy scene"
                best != null && best.second > 0f -> best.first
                else -> "Visual change"
            }
            results.add(
                DetectedClip(
                    startMs = s * 1000L,
                    endMs = min(durationMs, e * 1000L),
                    score = (sm[p] * 100).roundToInt().coerceIn(1, 99),
                    category = category,
                    title = "$category at ${stamp(p)}"
                )
            )
        }

        if (results.isEmpty()) {
            throw IllegalStateException("No standout moments were found. The video may be too flat (constant volume, no visual changes).")
        }
        return results.sortedByDescending { it.score }
    }

    /** Median of a[from until to] (the middle value; no averaging needed for this use). */
    private fun median(a: FloatArray, from: Int, to: Int): Float {
        if (to <= from) return a[from.coerceIn(0, a.size - 1)]
        val tmp = a.copyOfRange(from, to)
        tmp.sort()
        return tmp[tmp.size / 2]
    }

    private fun stamp(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    /** Index of the lowest-loudness second in [lo, hi]; on ties prefers the late or early side. */
    private fun quietest(db: FloatArray, lo: Int, hi: Int, preferLate: Boolean): Int {
        val a = lo.coerceIn(0, db.size - 1)
        val b = hi.coerceIn(a, db.size - 1)
        var best = a
        for (i in a..b) {
            val better = if (preferLate) db[i] <= db[best] else db[i] < db[best]
            if (better) best = i
        }
        return best
    }

    private fun percentile(values: FloatArray, p: Float): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sortedArray()
        return sorted[((sorted.size - 1) * p).toInt()]
    }

    /** Maps the 10th..95th percentile range to 0..1. */
    private fun normalizeRange(v: FloatArray): FloatArray {
        val lo = percentile(v, 0.10f)
        val hi = percentile(v, 0.95f)
        if (hi - lo < 1e-3f) return FloatArray(v.size)
        return FloatArray(v.size) { ((v[it] - lo) / (hi - lo)).coerceIn(0f, 1f) }
    }

    /** Scales so the 95th percentile becomes 1.0. */
    private fun normalizeTop(v: FloatArray): FloatArray {
        val hi = percentile(v, 0.95f)
        if (hi < 1e-4f) return FloatArray(v.size)
        return FloatArray(v.size) { (v[it] / hi).coerceIn(0f, 1f) }
    }
}
