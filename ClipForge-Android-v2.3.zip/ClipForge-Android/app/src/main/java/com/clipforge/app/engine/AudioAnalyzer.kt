package com.clipforge.app.engine

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Per-0.5 s measurements of the real audio track (all arrays have the same length):
 *  - rms:    loudness (0..1)
 *  - peak:   loudest single sample (0..1); a peak far above the rms means a sharp hit (impact, gunshot, explosion)
 *  - bright: how much of the sound is high-frequency (0..~1.4); shouting and excitement are brighter than
 *            game music or a calm voice
 */
class AudioSignal(val rms: FloatArray, val peak: FloatArray, val bright: FloatArray) {
    val size: Int get() = rms.size
    fun isEmpty(): Boolean = rms.isEmpty()

    companion object {
        val EMPTY = AudioSignal(FloatArray(0), FloatArray(0), FloatArray(0))
    }
}

/**
 * Decodes the real audio track of the video and measures loudness, peaks and brightness in 0.5 s windows.
 * Returns an empty signal when the video has no audio track.
 */
object AudioAnalyzer {
    const val HOP_MS = 500

    suspend fun analyze(path: String, durationMs: Long, onProgress: (Float) -> Unit): AudioSignal =
        withContext(Dispatchers.IO) {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(path)
                var track = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                        track = i
                        format = f
                        break
                    }
                }
                if (track < 0 || format == null) return@withContext AudioSignal.EMPTY

                extractor.selectTrack(track)
                val mime = format.getString(MediaFormat.KEY_MIME)!!
                val c = MediaCodec.createDecoderByType(mime)
                codec = c
                c.configure(format, null, null, 0)
                c.start()

                var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                var windowFrames = (rate.toLong() * HOP_MS / 1000).toInt().coerceAtLeast(1)
                var floatPcm = false

                val rmsList = ArrayList<Float>()
                val peakList = ArrayList<Float>()
                val brightList = ArrayList<Float>()
                var sumSq = 0.0
                var diffSq = 0.0
                var peak = 0.0
                var prev = 0.0
                var framesInWindow = 0

                fun closeWindow() {
                    val rms = sqrt(sumSq / framesInWindow)
                    rmsList.add(rms.toFloat())
                    peakList.add(peak.toFloat())
                    // Energy of the sample-to-sample difference compared with the signal energy:
                    // near 0 for deep/slow sound, higher for sharp, high-pitched sound.
                    brightList.add(sqrt(diffSq / (sumSq + 1e-12)).coerceIn(0.0, 2.0).toFloat())
                    sumSq = 0.0
                    diffSq = 0.0
                    peak = 0.0
                    framesInWindow = 0
                }

                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false

                while (!outputDone) {
                    ensureActive()
                    if (!inputDone) {
                        val inIdx = c.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val buf = c.getInputBuffer(inIdx)!!
                            val n = extractor.readSampleData(buf, 0)
                            if (n < 0) {
                                c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val outIdx = c.dequeueOutputBuffer(info, 10_000)
                    when {
                        outIdx >= 0 -> {
                            val out = c.getOutputBuffer(outIdx)!!
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            out.order(ByteOrder.nativeOrder())
                            val fb = if (floatPcm) out.asFloatBuffer() else null
                            val sb = if (!floatPcm) out.asShortBuffer() else null
                            val avail = (if (fb != null) fb.remaining() else sb!!.remaining()) / channels
                            for (k in 0 until avail) {
                                var mono = 0.0
                                for (ch in 0 until channels) {
                                    mono += if (fb != null) fb.get().toDouble() else sb!!.get() / 32768.0
                                }
                                mono /= channels
                                sumSq += mono * mono
                                val d = mono - prev
                                diffSq += d * d
                                prev = mono
                                val a = abs(mono)
                                if (a > peak) peak = a
                                framesInWindow++
                                if (framesInWindow >= windowFrames) closeWindow()
                            }
                            if (durationMs > 0) {
                                onProgress((info.presentationTimeUs / 1000f / durationMs).coerceIn(0f, 1f))
                            }
                            c.releaseOutputBuffer(outIdx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        }
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val nf = c.outputFormat
                            rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                            windowFrames = (rate.toLong() * HOP_MS / 1000).toInt().coerceAtLeast(1)
                            floatPcm = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        }
                    }
                }
                if (framesInWindow > 0) closeWindow()
                onProgress(1f)
                AudioSignal(rmsList.toFloatArray(), peakList.toFloatArray(), brightList.toFloatArray())
            } finally {
                try { codec?.stop() } catch (_: Exception) {}
                try { codec?.release() } catch (_: Exception) {}
                extractor.release()
            }
        }
}
